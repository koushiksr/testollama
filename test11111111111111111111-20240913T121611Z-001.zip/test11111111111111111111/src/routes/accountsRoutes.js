import express from 'express';
import { handleAccountFunctionCalling } from '../controllers/accountsController.js';

const router = express.Router();

router.post('/fc/invoice-parsing', handleAccountFunctionCalling);

export default router;
