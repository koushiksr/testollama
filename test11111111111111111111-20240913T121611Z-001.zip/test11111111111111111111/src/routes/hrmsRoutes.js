import express from 'express';
import { handleHRMSFunctionCalling } from '../controllers/hrmsController.js';

const router = express.Router();

// router.post("/pdf-json", handleHRMSPdfJson);
router.post('/fc/bulk-quetion', handleHRMSFunctionCalling);

export default router;
