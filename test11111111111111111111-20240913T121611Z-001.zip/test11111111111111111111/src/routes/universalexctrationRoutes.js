import express from 'express';
import { handleAccountPdfJson ,Test,Demo} from '../controllers/universalExtractinController.js';
const router = express.Router();

router.post('/pdf-json', handleAccountPdfJson);
router.post('/', Test);
router.post('/demo',Demo);
export default router;
