import express from "express";
import {
  handleTaskManagementPdfJson,
  handleTaskManagementFunctionCalling,
} from "../controllers/taskmanagementController.js";

const router = express.Router();

router.post("/pdf-json", handleTaskManagementPdfJson);
router.post("/functioncalling", handleTaskManagementFunctionCalling);

export default router;
