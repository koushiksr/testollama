import express from "express";
import {
  handleQRPdfJson,
  handleQRFunctionCalling,
} from "../controllers/qrController.js";

const router = express.Router();

router.post("/pdf-json", handleQRPdfJson);
router.post("/functioncalling", handleQRFunctionCalling);

export default router;
