import logToFile from "../../logToFile.js"

export default async function logger(req, res, next) {
    const start = Date.now();
    let ip = req.headers["x-forwarded-for"] || req.connection.remoteAddress;
    const userAgent = req.headers["user-agent"];
    const referrer = req.headers["referer"] || req.headers["referrer"]; 
    const method = req.method;
    const url = req.originalUrl;
    // if(ip!=="::ffff:192.168.100.21"){
      if(ip==="::ffff:192.168.30.101"){
        ip=ip+" deendayalu"
      }
      if(ip==="::ffff:192.168.30.88"){
        ip=ip+" koushik"
      }
      if(ip==="::ffff:192.168.30.31"){
        ip=ip+" koushik"
      }
      if(ip==="::ffff:192.168.30.106"){
        ip=ip+" niroj"
      }
      if(ip==="::ffff:192.168.30.25"){
        ip=ip+" sushank"
      }
      if(ip==="::ffff:192.168.30.74"){
        ip=ip+" manju"
      }
      if(ip==="::ffff:192.168.30.44"){
        ip=ip+" rajesh"
      }
      if(ip==="::ffff:192.168.30.41"){
        ip=ip+" megha"
      }
      if(ip==="::ffff:192.168.30.16"){
        ip=ip+" ravi"
      }
      // if(ip==="::ffff:192.168.30.16"){
      //   ip=ip+"ravi"
      // }
      const timestamp = new Date().toISOString();
      res.on("finish", async () => {
        const duration = Date.now() - start;
        const responseSize = res.getHeader("Content-Length") || 0;
        console.log(`${timestamp}|IP${ip}|${method} ${url.slice(12)}|Agent ${userAgent}|Refrr:${referrer}Dur:${duration}ms|ResSz:${responseSize}byts`)
        const durationLog = `${timestamp}|IP${ip}|${method} ${url.slice(12)}|Agent ${userAgent}|Refrr:${referrer}Dur:${duration}ms|ResSz:${responseSize}byts`;
        await logToFile(durationLog);
      });
    // }
    next();
  }