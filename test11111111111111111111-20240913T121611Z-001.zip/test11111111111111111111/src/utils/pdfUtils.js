import pdfParse from 'pdf-parse';
export function isValidJSON(str) {
  try {
    JSON.parse(str);
    return true;
  } catch (e) {
    return false;
  }
}

export async function extractTextFromPDF(pdfBuffer) {
  if (!pdfBuffer || pdfBuffer.length === 0) {
    throw new Error('PDF buffer is empty or invalid.');
  }

  try {
    console.log("e1");
    const data = await pdfParse(pdfBuffer);
    console.log("erfer");
    
    return data.text;
  } catch (error) {
    console.error('Failed to extract text from PDF:', error);
    throw new Error('Failed to extract text from PDF');
  }
}
