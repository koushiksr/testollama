import { extractTextFromPDF } from '../utils/pdfUtils.js';

export async function handleAccountFunctionCalling(req, res) {
  try {
    const schema = {
      Category: { type: 'string', enum: ['Rent', 'Utilities', 'COGS', 'Traveling', 'Salary', 'Advertising', 'Marketing', 'Other'], description: 'Expense or income category' },
      SubTotal: { type: 'number', default: 0, description: 'Amount before taxes and discounts' },
      Description: { type: 'string', default: '', description: 'Description of the invoice item' },
      TotalAmount: { type: 'number', default: 0, description: 'Total amount including taxes' },
      IGST: { type: 'number', default: 0, description: 'Integrated GST amount (percentage)' },
      CGST: { type: 'number', default: 0, description: 'Central GST amount (percentage)' },
      SGST: { type: 'number', default: 0, description: 'State GST amount (percentage)' },
      Date: { type: 'string', default: new Date().toISOString().split('T')[0], format: 'YYYY-MM-DD', description: 'Invoice date' },
      Cashflow_Income: { type: 'number', default: 0, description: 'Income from invoice' },
      Cashflow_Expense: { type: 'number', default: 0, description: 'Expense from invoice' },
      financial_Status: { type: 'string', enum: ['Assets', 'Liabilities'], default: 'Liabilities', description: 'Financial status' },
    };

    const systemPrompt = `You will be given text (invoice data) and a schema. Your task is to extract the required information from the text based on the schema and return it in a formatted JSON response. The response should include the following fields: Category, SubTotal, Description, TotalAmount, IGST (percentage), SGST (percentage), CGST (percentage), Date (format as YYYY-MM-DD), Cashflow_Income, Cashflow_Expense, and financial_Status. Ensure the JSON is pretty-printed with proper formatting. If a value is unknown, leave it empty.

    The valid tax percentages are as follows:
    - IGST: 0%, 0.25%, 3%, 5%, 12%, 18%, 28%
    - CGST: 0%, 0.125%, 1.5%, 2.5%, 6%, 9%, 14%
    - SGST: 0%, 0.125%, 1.5%, 2.5%, 6%, 9%, 14%

    Calculate the IGST, CGST, and SGST percentages based on the TotalAmount and SubTotal using the formula: (TotalAmount - SubTotal) / SubTotal * 100. 

    Ensure that:
    - Only use the valid tax percentages provided. If the calculated percentage does not match exactly, round to the nearest valid percentage.
    - If IGST is present, CGST and SGST should be set to 0%.
    - If CGST and SGST are present, IGST should be set to 0%.
    - If no tax is specified, assume IGST, CGST, and SGST are 0%.
    - Use the nearest valid percentage or default to 0% if no close match is found.

    Ensure the date format is YYYY-MM-DD.

    Here is the schema for reference:
    ${JSON.stringify(schema, null, 2)}

    Here is a sample JSON output format:
    {
      "Category": "Utilities",
      "SubTotal": 100,
      "Description": "about received data",
      "TotalAmount": 1000,
      "IGST": 18, // percentage
      "SGST": 0, // percentage
      "CGST": 0, // percentage
      "Date": "2024-02-25",
      "Cashflow_Income": 0,
      "Cashflow_Expense": 0,
      "financial_Status": "Assets"
    }`;
   console.log(req.files)
    if (!req.files || !req.files.pdfFile) {
      return res.status(400).json({ error: 'PDF file is required' });
    }

    const pdfFile = req.files.pdfFile;
    const pdfBuffer = pdfFile?.data;
    const textContent = await extractTextFromPDF(pdfBuffer);
    console.log(textContent);

    const prompt = `Analyze the following text to extract the following fields: Category, SubTotal, Description, TotalAmount, IGST (percentage), SGST (percentage), CGST (percentage), Date (format as YYYY-MM-DD), Cashflow_Income, Cashflow_Expense, and financial_Status.

    Calculate the IGST, CGST, and SGST percentages based on the total amount using the formula: (TotalAmount - SubTotal) / SubTotal * 100. Use the following valid percentages for calculation:
    
    - IGST: 0%, 0.25%, 3%, 5%, 12%, 18%, 28%
    - CGST: 0%, 0.125%, 1.5%, 2.5%, 6%, 9%, 14%
    - SGST: 0%, 0.125%, 1.5%, 2.5%, 6%, 9%, 14%

    Ensure that:
    
    - Only use the valid tax percentages provided. If the calculated percentage does not match exactly, round to the nearest valid percentage.
    - If IGST is present, CGST and SGST should be set to 0%.
    - If CGST and SGST are present, IGST should be set to 0%.
    - If no tax is specified, assume IGST, CGST, and SGST are 0%.
    - Use the nearest valid percentage or default to 0% if no close match is found.

    Ensure the date format is YYYY-MM-DD.

    Use the schema below to format the output as JSON:

    Schema:
    ${JSON.stringify(schema, null, 2)}

    Source Text:
    ${textContent}

    The output should be in this JSON format:
    {
      "Category": "Utilities",
      "SubTotal": 100,
      "Description": "about received data",
      "TotalAmount": 1000,
      "IGST": 18, // percentage
      "SGST": 0, // percentage
      "CGST": 0, // percentage
      "Date": "2024-02-25",
      "Cashflow_Income": 0,
      "Cashflow_Expense": 0,
      "financial_Status": "Assets"
    },   if you found nothing in data  give blanck data dont try to  give from example schema `;

    const result = await req.ollama.invoke(systemPrompt + ' Here is the prompt data: ' + prompt);
    console.log({ result });

    let parsedOutput;
    try {
      parsedOutput = JSON.parse(result);
    } catch (error) {
      console.error('Error parsing JSON:', error);
      return res.status(500).json({ error: 'Error parsing JSON response' });
    }

    res.status(200).json(parsedOutput);
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
}
