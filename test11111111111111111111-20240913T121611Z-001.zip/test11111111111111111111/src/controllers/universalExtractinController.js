import { extractTextFromPDF } from '../utils/pdfUtils.js';

export async function handleAccountPdfJson(req, res) {
  try {
    if (!req.body.prompt) {
      return res.status(400).json({ error: 'No prompt found!' });
    }

    let { prompt } = req.body;
    let text = req.body.text || 'undefined';

    let ip = req.headers["x-forwarded-for"] || req.connection.remoteAddress;
    const userAgent = req.headers["user-agent"];
    const referrer = req.headers["referer"] || req.headers["referrer"]; 
    const method = req.method;
    const url = req.originalUrl;
console.log({ip,userAgent,referrer,method,url})
    if (text === 'undefined') {
      const pdfFile = req.files?.pdfFile;

      if (!pdfFile) {
        return res.status(400).json({ error: 'PDF file is required' });
      }

      try {
        // Ensure we have a valid file buffer
        const pdfBuffer = pdfFile.data;
        if (!pdfBuffer || pdfBuffer.length === 0) {
          return res.status(400).json({ error: 'PDF buffer is empty or invalid' });
        }
        text = await extractTextFromPDF(pdfBuffer);
      } catch (error) {
        console.error('Error extracting text from PDF:', error);
        return res.status(400).json({ error: 'Failed to extract text from PDF' });
      }
    }

    const data = await req.ollama.invoke(`${text} ${prompt}`);
    const responseData = JSON.parse(data);
    res.status(200).json({ status: 'Response sent', data: responseData });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
}

export async function Test(req, res) {
  try {
    if (!req.body.prompt) {
      return res.status(400).json({ error: 'No prompt found!' });
    }
    console.log(req.body.prompt)
    const data = await req.ollama_string_io.invoke("i have a user prompt here take that text and  repond as less text as possible with string format  here is the quetion "+req.body.prompt+" it should be in string not json  or array ");
    res.status(200).send(data||"");
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
} 
export async function Demo(req,res){
try{
const a=await req.ollama_string_io.invoke("why sky is blue");
res.status(200).json(a)
}catch(error){
res.status(400).json({msg:"somthing went wrong!"})
}
}
