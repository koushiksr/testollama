project-directory/
│
├── server.js
├── controllers/
│ ├── accountsController.js
│ ├── taskmanagementController.js
│ ├── hrmsController.js
│ └── qrController.js
│
├── routes/
│ ├── accountsRoutes.js
│ ├── taskmanagementRoutes.js
│ ├── hrmsRoutes.js
│ └── qrRoutes.js
│
└── utils/
└── pdfUtils.js
