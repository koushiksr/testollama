import { PDFDocument } from 'pdf-lib';
import PDFParser from 'pdf-parse';

// Function to get the number of pages in a PDF
async function getPdfPageCount(pdfBuffer) {
  try {
    const pdfDoc = await PDFDocument.load(pdfBuffer);
    return pdfDoc.getPageCount();
  } catch (error) {
    console.error('Error loading PDF document:', error);
    throw error;
  }
}

// Function to extract text from a PDF
async function extractTextFromPDF(pdfBuffer) {
  try {
    const data = await PDFParser(pdfBuffer);
    return data.text; // Return the entire text from the PDF
  } catch (error) {
    console.error('Error extracting text from PDF:', error);
    throw error;
  }
}

// Function to split text into chunks simulating page ranges
function splitTextIntoPageChunks(text, numPages, pagesPerChunk) {
  const pages = [];
  const lines = text.split('\n'); // Split text into lines or use another delimiter if necessary

  // Example logic for splitting text based on pages (needs adjustment based on actual text format)
  const linesPerPage = Math.ceil(lines.length / numPages);
  for (let i = 0; i < numPages; i += pagesPerChunk) {
    const startLine = i * linesPerPage;
    const endLine = Math.min(startLine + pagesPerChunk * linesPerPage, lines.length);
    pages.push(lines.slice(startLine, endLine).join('\n'));
  }
  return pages;
}

// Function to process a chunk of text with the AI service
async function processTextWithAI(textContent, req) {
  const schema = {
    questions: {
      type: 'array',
      description: 'List of multiple-choice questions with options and correct answers',
      items: {
        type: 'object',
        properties: {
          question: { type: 'string', description: 'Text of the question' },
          options: {
            type: 'array',
            items: { type: 'string' },
            description: 'List of possible answers (option text only)',
          },
          correct: { type: 'string', description: 'Correct answer option' },
        },
        required: ['question', 'options', 'correct'],
      },
    },
  };

  const systemPrompt = `You will be given text from a document containing multiple-choice questions. Your task is to extract the questions, possible answers, and the correct answer for each question.

  Each question should be extracted with the following details:
  - Question text
  - Possible answers (without serial numbers, just the option text)
  - The correct answer (without the serial number of the option)

  Format your output as JSON with the structure below:
  {
    "questions": [
      {
        "question": "Your question text here",
        "options": [
          "option A",
          "option B",
          "option C",
          "option D"
        ],
        "correct": "Correct option"
      }
      // Repeat for all questions
    ]
  }

  Ensure that:
  - Each question includes a text field for the question, an array of answer options, and the correct answer option text.
  - The correct answer should not include the serial number of the option.
  - If no questions are found, return an empty array in the "questions" field.

   Here is the schema for reference:
  ${JSON.stringify(schema, null, 2)}

  Here is the sample JSON output format:
  {
    "questions": [
      {
        "question": "What is the capital of France?",
        "options": [
          "Berlin",
          "Madrid",
          "Paris",
          "Rome"
        ],
        "correct": "Paris"
      }
    ]
  }

  The provided text is:
  ${textContent}`;

  // Invoke the AI service with the constructed prompt
  // Replace this with your actual AI invocation code
  const result = await req.ollama.invoke(systemPrompt);
  return result;
}

// Function to handle the HRMS PDF JSON processing
export async function handleHRMSFunctionCalling(req, res) {
  try {
    // Check if the PDF file is provided
    if (!req.files || !req.files.pdfFile) {
      return res.status(400).json({ error: 'PDF file is required' });
    }

    const pdfFile = req.files.pdfFile;
    const pdfBuffer = pdfFile.data;

    // Get the number of pages in the PDF
    const numPages = await getPdfPageCount(pdfBuffer);

    // Extract text from the entire PDF
    const pdfText = await extractTextFromPDF(pdfBuffer);

    // Split text into chunks for each 2 pages
    const pagesPerChunk = 2;
    const chunks = splitTextIntoPageChunks(pdfText, numPages, pagesPerChunk);
    let combinedResults = [];

    // Process each chunk
    for (let i = 0; i < chunks.length; i++) {
      console.log(`Processing chunk ${i + 1} of ${chunks.length}`);

      const textContent = chunks[i];
      const result = await processTextWithAI(textContent, req);

      let parsedOutput;
      try {
        console.log({ result });
        parsedOutput = JSON.parse(result);
        if (parsedOutput.questions) {
          combinedResults = combinedResults.concat(parsedOutput.questions);
        }
      } catch (error) {
        console.error('Error parsing JSON:', error);
        return res.status(500).json({ error: 'Error parsing JSON response' });
      }
    }

    // Return combined results
    res.status(200).json({ questions: combinedResults });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
}
