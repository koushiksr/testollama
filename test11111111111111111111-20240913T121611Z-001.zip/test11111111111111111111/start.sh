#!/bin/bash
export NVM_DIR="/home/qugates/.nvm"
. "$NVM_DIR/nvm.sh"
cd /home/qugates/Documents/ollama_code/ollama_server
npm run dev 
