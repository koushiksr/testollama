import { promises as fs } from "fs";
import path from "path";
import { fileURLToPath } from "url";

// Calculate the directory name from the current module URL
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Define the path to the log file
const logFilePath = path.join(__dirname, "access.log");

const logToFile = async (logMessage) => {
  try {
    // Append the log message to the file
    await fs.appendFile(logFilePath, `${logMessage}\n`);
  } catch (err) {
    console.error("Failed to write log entry", err);
  }
};

export default logToFile;
