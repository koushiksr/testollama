import express from "express";
import cors from "cors";
import fileUpload from "express-fileupload";
import { Ollama } from "@langchain/community/llms/ollama";
import universalExtractionRoutes from "./src/routes/universalexctrationRoutes.js";
import accountsRoutes from "./src/routes/accountsRoutes.js";
import hrmsRoutes from "./src/routes/hrmsRoutes.js";
// import taskmanagementRoutes from './src/routes/taskmanagementRoutes.js';
// import qrRoutes from './src/routes/qrRoutes.js';
import logger from "./src/utils/logger.js"
const app = express();
const port = 5002;

// Initialize Ollama model
const ollama = new Ollama({
  baseUrl: "http://127.0.0.1",
  model: "llama3.1:8b",
  format: "json",
  keepAlive: -1,
  stream: false,
  options: { temperature: 0 },
});
const ollama_string_io = new Ollama({
  baseUrl: "http://127.0.0.1",
  model: "llama3.1:8b",
  // format: "json",
  keepAlive: -1,
  stream: false,
  options: { temperature: 0 },
});



// Middleware setup
app.use(express.json());

// Enable CORS
app.use(
  cors({
    origin: ["http://192.168.30.12", "http://localhost:5173","http://localhost:5174", "http://192.168.100.21","http://192.168.100.26", "http://192.168.30.38","http://192.168.30.74:5173"],
    methods: ["GET", "POST", "PUT", "DELETE"],
    allowedHeaders: ["Content-Type"],
  }),
);

// Configure file upload middleware
app.use(fileUpload());

//loggin users and errors
app.use(logger)

// Attach the Ollama model to the request object
app.use((req, res, next) => {
  req.ollama = ollama;
  req.ollama_string_io = ollama_string_io;
  next();
});

// Use routes
app.use("/", universalExtractionRoutes);
app.use("/api/ollama", universalExtractionRoutes);
app.use("/api/ollama/accounts", accountsRoutes);
app.use("/api/ollama/hrms", hrmsRoutes);
// app.use('/taskmanagement', taskmanagementRoutes);
// app.use('/qr', qrRoutes);

// Error handling middleware
app.use((err, req, res, next) => {
  console.error("Error:", err);
  res.status(500).json({ error: "Internal Server Error" });
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
